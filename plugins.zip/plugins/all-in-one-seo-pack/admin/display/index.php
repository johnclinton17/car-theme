<?php
/**
 * Silence is golden.
 */
