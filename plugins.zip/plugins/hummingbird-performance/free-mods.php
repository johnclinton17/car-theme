<?php

/**
 * This file is moved and rename during execution of npm run build or npm run release
 * Only the free version of the plugin will get this file
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WPHB_WPORG' ) ) {
	define( 'WPHB_WPORG', true );
}