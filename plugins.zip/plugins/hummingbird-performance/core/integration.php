<?php

include_once( 'integration/divi.php' );
include_once( 'integration/avada.php' );