<span>
    <?php _e( 'Saving changes will regenerate any necessary assets, this may take a few seconds to run.', 'wphb' ); ?>
</span>
