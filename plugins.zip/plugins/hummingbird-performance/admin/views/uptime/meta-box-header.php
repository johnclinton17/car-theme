<h3><?php echo $title; ?></h3>
<div class="buttons">
	<p class="wphb-label-notice-inline hide-to-mobile"><?php _e( 'Tip: A lower response time is better! Google recommends less than 200ms', 'wphb' ); ?></p>
</div>