<div class="buttons">
	<a href="<?php echo esc_url( $recheck_url ); ?>" class="button button-ghost" name="submit"><?php esc_html_e( 'Re-Check Status', 'wphb' ); ?></a>
</div>
<h3><?php echo esc_html( $title ); ?></h3>
