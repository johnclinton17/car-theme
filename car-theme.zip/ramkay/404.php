<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package dazzling
 */

get_header(); ?>
		<div class="navfull-width">
<section class="exchange-form">
  <div class="container">
  	<div class="pad-150">
  		<div class="pad-150">
    		<h1 style="color: #000;text-align: center;">404 page not found</h1>
    		<p style="text-align: center;">The page you are looking for is either moved or no more available. To navitate, please click on the links above. Thank you!</p>
    	</div>
    </div>  
    
   </div> 

</div><!-- navfullwisdth -->

<?php get_footer(); ?>