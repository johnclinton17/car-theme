<?php
/**
 * The template for displaying all pages.
 * Template Name: Home Page
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package atr
 */

get_header(); ?>

<!--   Home Banner-->
<section class="homebanner">
    <div class="flexslider">
        <ul class="slides">
            <?php
            $args = array( 'posts_per_page' => 5,'post_type' =>'homebanner','post_status'=> 'publish','orderby' => 'date','order' => 'ASC');
            $bannerposts = get_posts( $args );
            foreach ( $bannerposts as $bpost ) : setup_postdata( $bpost );
            $bannerimg = wp_get_attachment_url( get_post_thumbnail_id($bpost->ID) );
            $custom=get_post_custom($bpost->ID);?>
            
                <li>
                    <div class="bannerarea" style="background:url('<?php echo $bannerimg;?>') no-repeat scroll center top / cover ;">
                        <div class="container">
                            <div class="bannertext" style="float: <?php echo $custom['text_direction'][0];?>;?>">
                                <?php echo $bpost-> post_content; ?>
                            </div>
                        </div>   
                    </div>
                </li>                
            <?php endforeach; 
            wp_reset_postdata();?>
        </ul>
    </div> 
    <!-- portfolio section -->
    <section class="banner-portfolio">
        <div class=" hover01 column">
            <?php
              if( have_rows('banner_columns') ):
              while ( have_rows('banner_columns') ) : the_row(); ?>
            <div class="portfoliodiv">
                <a href="<?php the_sub_field('link');?>">
                    <figure>
                        <img src="<?php the_sub_field('image');?>" />
                        <div class="port-content">
                        <span class="small-title"><?php the_sub_field('title');?></span>
                        <span class="big-title"><?php the_sub_field('sub-title');?></span>
                        </div> 
                    </figure>  
                </a>
            </div> 
            <?php endwhile; endif; ?>   
        </div>   
    </section>
    <!-- portfolio section -->
</section>
<!--   Home Banner End-->
<section>
<div class="jeep-range">
    <div class="wrapper">
        <div class="range-title">
            <h4>The Jeep® Compass Range</h4>
        </div>
        <div class="car-range">
            <?php
              if( have_rows('compass_range') ):
              while ( have_rows('compass_range') ) : the_row(); ?>
            <div class="col-md-3 col-sm-6 pad0 mob-hidden">
              <a href="<?php echo esc_url( home_url( '/' ) ); ?><?php the_sub_field('link');?>" >
                <figure class="imghvr-shutter-in-">
                  <img src="<?php the_sub_field('image');?>">
                  <span class="car-name"><?php the_sub_field('car_name');?></span>
                  <span class="start-range"><?php the_sub_field('start_range');?></span>
                  <figcaption>
                    <?php the_sub_field('hiddentext');?>   
                  </figcaption>
                </figure>
              </a>  
            </div>
             <?php endwhile; endif; ?>   
             <div class="flexslider carrangeslider">
                <ul class="slides">
                     <?php
                      if( have_rows('compass_range') ):
                      while ( have_rows('compass_range') ) : the_row(); ?>
                        <li>
                          <div class="col-md-12 pad0">
                          <a href="<?php echo esc_url( home_url( '/' ) ); ?><?php the_sub_field('link');?>" >  
                            <figure class="imghvr-shutter-in-">
                              <img src="<?php the_sub_field('image');?>">
                              <span class="car-name"><?php the_sub_field('car_name');?></span>
                              <span class="start-range"><?php the_sub_field('start_range');?></span>
                              <figcaption>
                                <?php the_sub_field('hiddentext');?>   
                              </figcaption>
                            </figure>
                          </a>
                        </div>
                        </li>                
                   <?php endwhile; endif; ?>    
                </ul>
            </div>            
        </div>     
    </div>    
</div>
</section>

<section class="fcarange">
    <div class="container">
       <div class="row"> 
      
          <div class="col-sm-12 col-md-9">
              <div class="fca-title">
                  <h4>The FIAT range</h4>
              </div>
              <?php
                if( have_rows('fca_range') ):
                while ( have_rows('fca_range') ) : the_row(); ?>
            <div class="col-md-4 col-sm-4 fca-col">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?><?php the_sub_field('link');?>">
                <div class="row">
                    <img src="<?php the_sub_field('image');?>">
                    <span class="car-name"><?php the_sub_field('car_name');?></span>
                    <span class="start-range"><?php the_sub_field('start_range');?></span>        
                </div>
                </a>
            </div>
            <?php endwhile; endif; ?>
          </div>

          <?php
          if( have_rows('abarth_range') ):
          while ( have_rows('abarth_range') ) : the_row(); ?>
          <div class="col-sm-12 col-md-3 abarth-range">
            <div class="fca-title">
                <h4>The ABARTH </h4>
            </div>
            <div class="col-md-12 col-sm-4 col-xs-12 fca-col abarth-col col-centered">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?><?php the_sub_field('link');?>">
                <div class="row">
                    <img src="<?php the_sub_field('image');?>">
                    <span class="car-name"><?php the_sub_field('car_name');?></span>
                    <span class="start-range"><?php the_sub_field('start_range');?></span>        
                </div>
                </a>
            </div>
            <?php endwhile; endif; ?>
          </div>
       </div>
    </div>    
</section>

<section class="testimonials">
    <div class="container">
        <div class="testimonials-title">
            <h3>Customer</h3>
            <h4>Testimonials</h4>
            <hr class="orange">
        </div>
        <div class="row">
        <div class="col-md-12" data-wow-delay="0.2s">
          <div class="carousel slide" id="quote-carousel">
            <!-- Bottom Carousel Indicators -->
            <ol class="carousel-indicators">
             <?php
            $args = array( 'posts_per_page' => -1,'post_type' =>'testimonial','post_status'=> 'publish','orderby' => 'date','order' => 'ASC');
            $testimonialimgs = get_posts( $args );
			$i=1;
            foreach ( $testimonialimgs as $testimg ) : setup_postdata( $testimg );
            $testimonialimg = wp_get_attachment_url( get_post_thumbnail_id($testimg->ID) );?>
            
              <li class="item-btn"><img class="img-responsive " src="<?php echo $testimonialimg;?>" alt="">
              </li>
              
              <?php   $i++;
			  endforeach; 
            wp_reset_postdata();?>
              <?php /*?><li class="item-btn active"><img class="img-responsive" src="<?php echo get_template_directory_uri();?>/inc/images/icon-testimonial.png" alt="">
              </li>
              <li class="item-btn"><img class="img-responsive" src="<?php echo get_template_directory_uri();?>/inc/images/icon-testimonial.png" alt="">
              </li><?php */?>
              
            </ol>

            <!-- Carousel Slides / Quotes -->
            <div class="carousel-inner text-center">
              <?php
            $args = array( 'posts_per_page' => -1,'post_type' =>'testimonial','post_status'=> 'publish','orderby' => 'date','order' => 'ASC');
            $testimonialposts = get_posts( $args );
			$i=1;
            foreach ( $testimonialposts as $testpost ) : setup_postdata( $testpost );
			//print_r($testpost);
            $testimonialimg = wp_get_attachment_url( get_post_thumbnail_id($testpost->ID) );?>
            
              <!-- Quote 1 -->
              <div class="item <?php if($i==1):?> active <?php endif;?>">
                <blockquote>
                  <div class="row">
                    <div class="col-sm-8 col-sm-offset-2">
                      <?php echo $testpost->post_content;?>
                    </div>
                  </div>
                </blockquote>
              </div>
              
              <?php $i++;
			  endforeach; 
            wp_reset_postdata();?>
            
            
            </div>

            <!-- Carousel Buttons Next/Prev -->
            <a href="javascript:void(0)" class="left carousel-control"><!-- <i class="fa fa-chevron-left"></i> --></a>
            <a href="javascript:void(0)" class="right carousel-control"><!-- <i class="fa fa-chevron-right"></i> --></a>
          </div>
        </div>
      </div>
    </div>    
</section>
<section class="about">
    <div class="container">
        <div class="col-md-6 border-right">
            <h4 class="aboutme">About Ramkay FCA</h4>
            <h3 class="about-sub">Ramkay Fiat is the Dealer of Jeep and Fiat vehicles in Chennai.</h3>
            <span class="about-content">
                The dealership is located at Nungambakkam and the workshop at Perungudi. The Mopar branded workshop is the largest facility for Fiat in India. With 26 work bays, the workshop has state-of-the-art equipments and Fiat trained manpower. It also has a body shop and a well stocked parts counter.
            </span>
            <a class="orange" href="<?php echo esc_url( home_url( '/' ) ); ?>about-us/">Read More</a>
            <br>
            <h4 class="aboutme">Quick links</h4>
            <div class="col-md-6 col-sm-6 pad0">

                <a href="<?php echo esc_url( home_url( '/' ) ); ?>request-brochure" target="_blank" class="quicklinks">Request brochure </a>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>service/" target="_blank" class="quicklinks">Service appointment  </a>
            </div>
            <div class="col-md-6 col-sm-6 pad0">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>insurance" target="_blank" class="quicklinks">Insurance renewal</a>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>arrange-a-loan" target="_blank" class="quicklinks">Arrange a loan</a>
            </div>

        </div>
        <div class="col-md-6 ">
            <h4 class="aboutme center">Have a question?</h4>
            <?php echo do_shortcode( '[contact-form-7 id="691" title="enquiry"]' ); ?>
        </div>
    </div>    
</section>

<section class="map-sec">
  <div id="map"></div>
</section>

<script type="text/javascript">
  
  jQuery(window).load(function() {
  jQuery('.carrangeslider').flexslider({
    animation: "slide"
  });
});
</script>

<!-- Google Map API -->
  <script>
      function initMap() {
        // Styles a map in night mode.
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 13.053479, lng: 80.248402},
          zoom: 16,
          styles: [
              {elementType: 'geometry', stylers: [{color: '#f3e6d1'}]},
              {elementType: 'labels.text.fill', stylers: [{color: '#bfa172'}]},
              {elementType: 'labels.text.stroke', stylers: [{color: '#fff'}]},
              {
                featureType: 'administrative',
                elementType: 'geometry.stroke',
                stylers: [{color: '#91754a'}]
              },
              {
                featureType: 'administrative.land_parcel',
                elementType: 'geometry.stroke',
                stylers: [{color: '#91754a'}]
              },
              {
                featureType: 'administrative.land_parcel',
                elementType: 'labels.text.fill',
                stylers: [{color: '#91754a'}]
              },
              {
                featureType: 'landscape.natural',
                elementType: 'geometry',
                stylers: [{color: '#91754a'}]
              },
              {
                featureType: 'poi',
                elementType: 'geometry',
                stylers: [{color: '#f1e3cc'}]
              },
              {
                featureType: 'poi',
                elementType: 'labels.text.fill',
                stylers: [{color: '#91754a'}]
              },
              {
                featureType: 'poi.park',
                elementType: 'geometry.fill',
                stylers: [{color: '#f1e3cc'}]
              },
              {
                featureType: 'poi.park',
                elementType: 'labels.text.fill',
                stylers: [{color: '#91754a'}]
              },
              {
                featureType: 'road',
                elementType: 'geometry',
                stylers: [{color: '#fff7ea'}]
              },
              {
                featureType: 'road.arterial',
                elementType: 'geometry',
                stylers: [{color: '#fff7ea'}]
              },
              {
                featureType: 'road.highway',
                elementType: 'geometry',
                stylers: [{color: '#fff7ea'}]
              },
              {
                featureType: 'road.highway',
                elementType: 'geometry.stroke',
                stylers: [{color: '#fff7ea'}]
              },
              {
                featureType: 'road.highway.controlled_access',
                elementType: 'geometry',
                stylers: [{color: '#fff7ea'}]
              },
              {
                featureType: 'road.highway.controlled_access',
                elementType: 'geometry.stroke',
                stylers: [{color: '#db8555'}]
              },
              {
                featureType: 'road.local',
                elementType: 'labels.text.fill',
                stylers: [{color: '#806b63'}]
              },
              {
                featureType: 'transit.line',
                elementType: 'geometry',
                stylers: [{color: '#dfd2ae'}]
              },
              {
                featureType: 'transit.line',
                elementType: 'labels.text.fill',
                stylers: [{color: '#8f7d77'}]
              },
              {
                featureType: 'transit.line',
                elementType: 'labels.text.stroke',
                stylers: [{color: '#ebe3cd'}]
              },
              {
                featureType: 'transit.station',
                elementType: 'geometry',
                stylers: [{color: '#dfd2ae'}]
              },
              {
                featureType: 'water',
                elementType: 'geometry.fill',
                stylers: [{color: '#b9d3c2'}]
              },
              {
                featureType: 'water',
                elementType: 'labels.text.fill',
                stylers: [{color: '#92998d'}]
              }
            ]
        });
    
     var marker = new google.maps.Marker({
          position: new google.maps.LatLng(13.053479,80.248402),
          map: map,
      title: 'Ramkay FCA',
      icon: '<?php bloginfo('template_url'); ?>/inc/images/location-pointer.png'
    });
    var contentString = 'Ramkay FCA';
    var infowindow = new google.maps.InfoWindow({
          content: contentString
        });

    }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBrcYG1OunNyOP73to9Sp549r-OQSUOJtw&callback=initMap"
    async defer></script>
<?php //get_sidebar(); ?>
<?php get_footer(); ?>
