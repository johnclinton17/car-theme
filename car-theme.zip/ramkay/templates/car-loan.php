<?php
/**
 * Template Name: carloan -template
 *
 * @package dazzling
 */

get_header(); ?>
  
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->
<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext contactus">
              <?php the_content(); ?>               
            </div>
            
          </div>

        </div>
    </div>
</section>

<section class="carloan-form">
  <div class="container">
      
    <h3>Ramkay has partnered with leading financial institutions to offer you exciting loans to own your favorite vehicles.</h3>
    
    <div class="formsec col-md-8 col-centered">
      <h4>The loan details are as follows:</h4>

      <div class="" style="overflow-x:auto;">
        <table>
          <tr>
            <th>Amount \ Tennure</th>
            <th>1 year</th>
            <th>2 year</th>
            <th>3 year</th>
            <th>4 year</th>
            <th>5 year</th>
            <th>6 year</th>
            <th>7 year</th>
          </tr>
          <tr>
            <td>1 Lakh</td>
            <td>8731</td>
            <td>4555</td>
            <td>3166</td>
            <td>2474</td>
            <td>2061</td>
            <td>1788</td>
            <td>1594</td>
          </tr>
          <tr>
            <td>2 Lakh</td>
            <td>17462</td>
            <td>9109</td>
            <td>6332</td>
            <td>4949</td>
            <td>4123</td>
            <td>3575</td>
            <td>3187</td>
          </tr>
          <tr>
            <td>3 Lakh</td>
            <td>26194</td>
            <td>13664</td>
            <td>9498</td>
            <td>7424</td>
            <td>6185</td>
            <td>5362</td>
            <td>4780</td>
          </tr>
          <tr>
            <td>4 Lakh</td>
            <td>34925</td>
            <td>18218</td>
            <td>12664</td>
            <td>9899</td>
            <td>8247</td>
            <td>7149</td>
            <td>6373</td>
          </tr>
          <tr>
            <td>5 Lakh</td>
            <td>43656</td>
            <td>22772</td>
            <td>15830</td>
            <td>12374</td>
            <td>10309</td>
            <td>8936</td>
            <td>7966</td>
          </tr>
          <tr>
            <td>6 Lakh</td>
            <td>52388</td>
            <td>27327</td>
            <td>18996</td>
            <td>14849</td>
            <td>12371</td>
            <td>10723</td>
            <td>9559</td>
          </tr>
          <tr>
            <td>7 Lakh</td>
            <td>61119</td>
            <td>31881</td>
            <td>22162</td>
            <td>17324</td>
            <td>14433</td>
            <td>12510</td>
            <td>11152</td>
          </tr>
        </table>
      </div>  

    </div>  

    <div class="exchange-form">
      <h3>If you have a loan requirement, please get in touch with us:</h3>
      <div class="col-md-8 col-centered">
        <?php echo do_shortcode('[contact-form-7 id="1037" title="car loan"]'); ?>
      </div>
    </div>  
  </div>
</section>  



</div><!-- navfullwisdth -->




<script>
    new WOW().init();

jQuery(document).ready(function(){
jQuery("#exchangename").keypress(function(event){
    var inputValue = event.charCode;
    if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
        event.preventDefault();
    }
});
});


jQuery("#exchangephone").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});
</script>
<?php endwhile; // end of the loop. ?>  
<?php get_footer(); ?>
 