<?php
/**
 * Template Name: servicerequest-template
 *
 * @package dazzling
 */

get_header(); ?>
  
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->
<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext contactus">
                        
            </div>
            
          </div>

        </div>
    </div>
</section>

<section class="exchange-form">
  <div class="container">
      <span class="page-tit"><?php the_content(); ?></span>
      
    <div class="form col-md-10 col-centered">
      <div class="phonecontact col-md-12">
        <div class="col-sm-3 col-md-3 icon-div-call">
          <h4>CALL US</h4>
          <h5>994-01-77-000</h5>
        </div>
        <div class="col-sm-5 col-md-5 icon-div-email">
          <h4>EMAIL US</h4>
          <h5><a href="mailto:service-pgd@ramkay-fca.com">service-pgd@ramkay-fca.com</a></h5>
        </div>
        <div class="col-sm-4 col-md-4 icon-div-form">
          <h4>Service Request</h4>
          <h5><a type="button" data-toggle="modal" data-target="#myModal">Submit the form</a></h5>
        </div>
      </div>
    </div>
    <div class="col-md-10 col-centered border-top">
      <div class="row">
        <div class="col-md-3">
          <div class="row">
            <img src="<?php the_field('logo_img');?>">
          </div>  
        </div>
        <div class="col-md-9">
          <div class="row">
           <!-- <span class="advantages-tit"><?php the_field('title');?></span> -->
           <span class="advantages-content"><?php the_field('content');?></span>
           <br>
           <img src="<?php the_field('img');?>">
           <span class="img-tit">Mopar Service Centre</span>
           <div class="image-row">
            <?php
              if( have_rows('img_row') ):
              while ( have_rows('img_row') ) : the_row(); ?>   
              <div class="col-md-4 col-sm-6 col-xs-6 box-image">
                <img src="<?php the_sub_field('image');?>">
                <span class="img-tit"><?php the_sub_field('img_title');?></span>
              </div>
            <?php endwhile; endif; ?>    
           </div> 
          </div>
        </div> 
      </div>
    </div>
  
  </div>
</section>  


<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
      </div>
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <span class="page-tit">Service Appointment Request</span>
        <?php echo do_shortcode('[contact-form-7 id="710" title="service"]'); ?>
      </div>
      <div class="modal-footer">
      </div>
    </div>

  </div>
  <script type="text/javascript">
    document.getElementById("servicecenteres4").style.display = 'none';
document.getElementById("servicecenteres1").style.display = 'none';
document.getElementById("servicecenteres2").style.display = 'none';
document.getElementById("servicecenteres3").style.display = 'none';

  document.getElementById("model").addEventListener("change", displayTextField);
  function displayTextField() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "Punto EVO") {
      document.getElementById("servicecenteres1").style.display = 'block';
    } else {
      document.getElementById("servicecenteres1").style.display = 'none';
    }
  }

  document.getElementById("model").addEventListener("change", displayTextField2);  
  function displayTextField2() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "New Linea") {
      document.getElementById("servicecenteres2").style.display = 'block';
    } else {
      document.getElementById("servicecenteres2").style.display = 'none';
    }
  }

  document.getElementById("model").addEventListener("change", displayTextField3);  
  function displayTextField3() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "Abarth") {
      document.getElementById("servicecenteres3").style.display = 'block';
    } else {
      document.getElementById("servicecenteres3").style.display = 'none';
    }
  }

    document.getElementById("model").addEventListener("change", displayTextField4);
  function displayTextField4() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "Urban Cross") {
      document.getElementById("servicecenteres4").style.display = 'block';
    } else {
      document.getElementById("servicecenteres4").style.display = 'none';
    }
  }

  </script>
</div>
</div><!-- navfullwisdth -->




<script>
    new WOW().init();

jQuery(document).ready(function(){
jQuery("#exchangename").keypress(function(event){
    var inputValue = event.charCode;
    if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
        event.preventDefault();
    }
});
});


jQuery("#exchangephone").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});


document.getElementById("servicecenteres4").style.display = 'none';
document.getElementById("servicecenteres1").style.display = 'none';
document.getElementById("servicecenteres2").style.display = 'none';
document.getElementById("servicecenteres3").style.display = 'none';

  document.getElementById("model").addEventListener("change", displayTextField);
  function displayTextField() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "Punto EVO") {
      document.getElementById("servicecenteres1").style.display = 'block';
    } else {
      document.getElementById("servicecenteres1").style.display = 'none';
    }
  }

  document.getElementById("model").addEventListener("change", displayTextField2);  
  function displayTextField2() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "New Linea") {
      document.getElementById("servicecenteres2").style.display = 'block';
    } else {
      document.getElementById("servicecenteres2").style.display = 'none';
    }
  }

  document.getElementById("model").addEventListener("change", displayTextField3);  
  function displayTextField3() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "Abarth") {
      document.getElementById("servicecenteres3").style.display = 'block';
    } else {
      document.getElementById("servicecenteres3").style.display = 'none';
    }
  }

    document.getElementById("model").addEventListener("change", displayTextField4);
  function displayTextField4() {
    // Get the value of the selected drop down
    var dropDownText =  document.getElementById("model").value;
    // If selected text matches 'Other', display the text field.
    if (dropDownText == "Urban Cross") {
      document.getElementById("servicecenteres4").style.display = 'block';
    } else {
      document.getElementById("servicecenteres4").style.display = 'none';
    }
  }

</script>
<?php endwhile; // end of the loop. ?>  
<?php get_footer(); ?>
 