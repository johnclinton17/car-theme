<?php
/**
 * Template Name: single-compass-template
 *
 * This is the template that displays full width page without sidebar
 *
 * @package dazzling
 */

get_header(); ?>
	
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->

<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext jeep">
              <?php the_content(); ?>               
            </div>
            
          </div>

        </div>
    </div>
</section>


<section class="specs-row">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
          <div class="row">
            <?php
              if( have_rows('left_side') ):
              while ( have_rows('left_side') ) : the_row(); ?>   
                <div class="feat-row">
                  <h3 class="car-feat-title"><?php the_sub_field('title');?></h3>
                  <?php the_sub_field('features');?>  
                </div>
            <?php endwhile; endif; ?>  
          </div>
      </div>
      <div class="col-md-6">
        <div class="row">

          <?php
              if( have_rows('right_side') ):
              while ( have_rows('right_side') ) : the_row(); ?>   
                <div class="feat-row">
                  <h3 class="car-feat-title"><?php the_sub_field('title');?></h3>
                  <?php the_sub_field('features');?>  
                </div>
            <?php endwhile; endif; ?>  

        </div>
      </div>
    </div>  <!-- row -->
    <div class="row">
      <h3 class="car-feat-title acc">Technical Specifications</h3>
      <?php the_field('specifications');?>  
    </div>

  </div>   <!-- container -->
</section>

<section class="specs-row">
  <div class="container">
   
</div>
</section>





</div><!-- navfullwisdth -->





<script>
    new WOW().init();



</script>
<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
 