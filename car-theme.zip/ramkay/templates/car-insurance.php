<?php
/**
 * Template Name: car-insurance-template
 *
 * This is the template that displays full width page without sidebar
 *
 * @package dazzling
 */

get_header(); ?>
	
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->

<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext contactus">
              <?php the_content(); ?>               
            </div>
            
          </div>

        </div>
    </div>
</section>
<div id="carinsurance">
<section class="car-insurance">
    <div class="container">

    <span class="exchange-text">Mopar Assure</span>
    <span class="exchange-text-small">Please get in touch with your car details and our customer support will process the requirement.</span>


    <div class="form col-md-12 col-centered">
      <div class="col-md-7 testdrive">
          <?php echo do_shortcode('[contact-form-7 id="735" title="car insurance"]'); ?>
      </div> 
      <div class="phonecontact col-md-5">
        <div class="col-sm-12">
          <img src="<?php echo get_template_directory_uri(); ?>/inc/images/mophar-assure.png" alt="car insurance"> 
        </div>
      </div>
      
    </div>

</div>
</section>
</div>

<!-- <div id="caraccessoriessec" >
<section class="car-accessories">
    <div class="container">
        <span class="exchange-text">Car Accessories</span>
        <span class="exchange-text-small">Download Our Car Accessories catalogue</span>

        <a href="http://server/prabavathy/ramkay/website/wp-content/uploads/2017/11/Accessories.pdf" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/pdf_download.png" alt="pdf download" class="center pad-top"> </a>
    </div>    
</section>
</div>
<div id="customercaresec" >

<section class="customer-care">
    <div class="container">
        <span class="exchange-text">Customer Care</span>

        <div class="image-row col-md-8">
            <span class="image-head">Advanced Car Wash Facility</span>
            <div class="col-md-6"><div class="row"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/car1.jpg" alt="" class=""></div></div>
            <div class="col-md-6"><div class="row"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/car2.jpg" alt="" class=""></div></div>
        </div> 
        <div class="image-row col-md-4">
            <span class="image-head">For emergency needs – Service on the Move</span>
            <div class="col-md-12"><div class="row"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/car3.jpg" alt="" class=""></div></div>
        </div> 
        <div class="image-row col-md-12">
            <span class="image-head">An array of vehicles for test drive</span>
            <img src="<?php echo get_template_directory_uri(); ?>/inc/images/customer-care-new.jpg" alt="" class="">
        </div>    
                
        <div class="image-row col-md-12">
            <a href="http://server/prabavathy/ramkay/website/wp-content/uploads/2017/11/TOP-200-Parts-List-Jan-2016.xls" class="download-pdf" alt="Top 200 Parts List" download >Download Top 200 Parts List</a>
        </div>
    </div>    
</section>
 -->
</div>







</div><!-- navfullwisdth -->





<script>
    new WOW().init();


jQuery('#stickynav').affix({
    offset: {
        top: jQuery('#stickynav').offset().top
    }
});


jQuery(document).ready(function () {
    jQuery(document).on("scroll", onScroll);
    
    //smoothscroll
    jQuery('.stickyjeep .nav li a[href^="#"]').on('click', function (e) {
        e.preventDefault();
        jQuery(document).off("scroll");
        
        jQuery('.stickyjeep .nav li a').each(function () {
            jQuery(this).removeClass('active');
        })
        jQuery(this).addClass('active');
      
        var target = this.hash,
            menu = target;
        $target = jQuery(target);
        jQuery('html, body').stop().animate({
            'scrollTop': $target.offset().top}, 500, 'swing', function () {
            window.location.hash = target;
            jQuery(document).on("scroll", onScroll);
        });
    });
});


function onScroll(event){
    var scrollPos = jQuery(document).scrollTop();
   jQuery('#stickynav ul li a').each(function () {
        var currLink = jQuery(this);
        var refElement = jQuery(currLink.attr("href"));
        if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            jQuery('#stickynav ul li a').removeClass("active");
            currLink.addClass("active");
        }
        else{
            currLink.removeClass("active");
        }
    });
}

jQuery(document).ready(function(){
    jQuery("#exchangename").keypress(function(event){
        var inputValue = event.charCode;
        if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
            event.preventDefault();
        }
    });
});

jQuery("#exchangephone").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});
jQuery("#year").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});
jQuery("#value").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});

</script>
<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
 