<?php
/**
 * Template Name: brochure-request-template
 *
 * @package dazzling
 */

get_header(); ?>
  
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->
<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext contactus">
              <?php the_content(); ?>               
            </div>
            
          </div>

        </div>
    </div>
</section>

<section class="exchange-form">
  <div class="container">
      
    <div class="form col-md-12 col-centered">
      <div class="phonecontact col-md-4">
        <div class="col-sm-12 icon-div-call">
          <h4>CALL US</h4>
          <h5>044 2496 3447</h5>
        </div>
        <div class="col-sm-12 icon-div-email">
          <h4>EMAIL US</h4>
          <h5><a href="mailto:jeep@ramkay-fca.com">jeep@ramkay-fca.com</a></h5>
        </div>
      </div>
      <div class="col-md-8 border-left testdrive">
          <?php echo do_shortcode('[contact-form-7 id="760" title="Brochure"]'); ?>
      </div> 
    </div>
  
  </div>
</section>  



</div><!-- navfullwisdth -->




<script>
    new WOW().init();

jQuery(document).ready(function(){
jQuery("#exchangename").keypress(function(event){
    var inputValue = event.charCode;
    if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
        event.preventDefault();
    }
});
});


jQuery("#exchangephone").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});
</script>
<?php endwhile; // end of the loop. ?>  
<?php get_footer(); ?>
 