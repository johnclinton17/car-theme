<?php
/**
 * Template Name: contact-template
 *
 * @package dazzling
 */

get_header(); ?>
  
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->
<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext contactus">
              <?php the_content(); ?>               
            </div>
            
          </div>

        </div>
    </div>
</section>

<section class="contact-sec">
  <div class="container">
      <div class="alerttime">
        <span class="pickup">Free pickup and drop anywhere in Chennai, from 7.30 AM onwards</span>
      </div>  
      <div class="col-md-6 contact-content">
        <?php the_field('left_content');?>
      </div>
      <div class="col-md-6 contact-content border-left">
        <?php the_field('right_content');?>
      </div>
  </div>  
</section>

<section class="map">
  <div class="container">
    <h3>Locate us on Google Maps</h3>
    <div class="col-md-6">
      <span class="exchange-text-small">Showroom</span>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d62199.41328418797!2d80.21375835509305!3d13.00614014171284!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x5009a0d84c56c7bb!2sRamkay+FCA!5e0!3m2!1sen!2sin!4v1511167621537" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <div class="col-md-6">
        <span class="exchange-text-small">Workshop</span>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7776.435562432917!2d80.2468366365735!3d12.95791171973878!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a525d1729bc9873%3A0xb9e9e8e0d4b767c3!2sRamkay+Fiat+Service!5e0!3m2!1sen!2sin!4v1511167717402" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
  </div>  
</section>
</div><!-- navfullwisdth -->





<script>
    new WOW().init();

</script>
<?php endwhile; // end of the loop. ?>  
<?php get_footer(); ?>
 