<?php
/**
 * Template Name: fiat -template
 *
 * This is the template that displays full width page without sidebar
 *
 * @package dazzling
 */

get_header(); ?>
	
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">


<!--   Home Banner-->
<div id="Overviewsec">
<section  class="innerbanner" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover	;"> 
	<div class="container">
    	<div class="row"> 
        	<div class="col-sm-12 col-sm-12 innerbannertext">
        		<div class="bannertext jeep">
        			<?php the_content(); ?>		            
               	</div>
        		
        	</div>

        </div>
    </div>
</section>

<section class="fiat-cars">
  <div class="container">
    <div class="row"> 
      <?php
        if( have_rows('car_row') ):
        while ( have_rows('car_row') ) : the_row(); ?> 
          <div class="col-md-4 col-sm-4 cars-block">
            <div class="wrapper">
              <a href="<?php the_sub_field('link');?>">
              <img src="<?php the_sub_field('image');?>">
              <div class="car-content">
                <?php the_sub_field('content');?>
              </div>  
              </a>
            </div>
          </div>  
      <?php endwhile; endif; ?>       
    </div>
  </div>  
</section>





</div><!-- navfullwisdth -->





<script>
    new WOW().init();

   
</script>
<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
 