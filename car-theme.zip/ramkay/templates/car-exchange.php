<?php
/**
 * Template Name: car-exchange-template
 *
 * @package dazzling
 */

get_header(); ?>
  
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->
<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext contactus">
              <?php the_content(); ?>               
            </div>
            
          </div>

        </div>
    </div>
</section>

<section class="exchange-form">
  <div class="container">
    <span class="exchange-text">Exchange your old car for a brand new Jeep/Fiat model!</span>
    <span class="exchange-text-small">To assess the value of your car, please provide us the following details:</span>
    <div class="form">
      <div class="col-md-8 col-centered">
        
          <?php echo do_shortcode('[contact-form-7 id="43" title="Car exchange"]'); ?>
        
      </div> 
    </div>
    <span class="disclaimer">Disclaimer : Exchange rate is a rough estimation. Actual estimate will be provided after evaluation of car in person.</span>  
  </div>
</section>  



</div><!-- navfullwisdth -->




<script>
    new WOW().init();

jQuery(document).ready(function(){
jQuery("#exchangename").keypress(function(event){
    var inputValue = event.charCode;
    if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
        event.preventDefault();
    }
});
});

jQuery(document).ready(function(){
jQuery("#carcolor").keypress(function(event){
    var inputValue = event.charCode;
    if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
        event.preventDefault();
    }
});
});

jQuery("#exchangephone").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});
jQuery("#caryear").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});
jQuery("#carodo").keypress(function(event) {
  return /\d/.test(String.fromCharCode(event.keyCode));
});

</script>
<?php endwhile; // end of the loop. ?>  
<?php get_footer(); ?>
 