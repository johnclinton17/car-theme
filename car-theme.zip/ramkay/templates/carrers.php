<?php
/**
 * Template Name: careers-template
 *
 * This is the template that displays full width page without sidebar
 *
 * @package dazzling
 */

get_header(); ?>
	
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<!--   Home Banner-->

<section  class="innerbanner contact" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover  ;"> 
  <div class="container">
      <div class="row"> 
          <div class="col-sm-12 col-sm-12 innerbannertext">
            <div class="bannertext contactus">
              <?php the_content(); ?>               
            </div>
            
          </div>

        </div>
    </div>
</section>
<div id="carinsurance">
<section class="car-insurance">
    <div class="container">

    <div class="carrers"><?php the_field('carrers-content');?> </div>

  </div>
</section>
</div>

<!-- <div id="caraccessoriessec" >
<section class="car-accessories">
    <div class="container">
        <span class="exchange-text">Car Accessories</span>
        <span class="exchange-text-small">Download Our Car Accessories catalogue</span>

        <a href="http://server/prabavathy/ramkay/website/wp-content/uploads/2017/11/Accessories.pdf" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/pdf_download.png" alt="pdf download" class="center pad-top"> </a>
    </div>    
</section>
</div>
<div id="customercaresec" >

<section class="customer-care">
    <div class="container">
        <span class="exchange-text">Customer Care</span>

        <div class="image-row col-md-8">
            <span class="image-head">Advanced Car Wash Facility</span>
            <div class="col-md-6"><div class="row"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/car1.jpg" alt="" class=""></div></div>
            <div class="col-md-6"><div class="row"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/car2.jpg" alt="" class=""></div></div>
        </div> 
        <div class="image-row col-md-4">
            <span class="image-head">For emergency needs – Service on the Move</span>
            <div class="col-md-12"><div class="row"><img src="<?php echo get_template_directory_uri(); ?>/inc/images/car3.jpg" alt="" class=""></div></div>
        </div> 
        <div class="image-row col-md-12">
            <span class="image-head">An array of vehicles for test drive</span>
            <img src="<?php echo get_template_directory_uri(); ?>/inc/images/customer-care-new.jpg" alt="" class="">
        </div>    
                
        <div class="image-row col-md-12">
            <a href="http://server/prabavathy/ramkay/website/wp-content/uploads/2017/11/TOP-200-Parts-List-Jan-2016.xls" class="download-pdf" alt="Top 200 Parts List" download >Download Top 200 Parts List</a>
        </div>
    </div>    
</section>
 -->
</div>







</div><!-- navfullwisdth -->





<script>
    new WOW().init();



</script>
<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
 