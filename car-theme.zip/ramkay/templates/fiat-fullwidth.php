<?php
/**
 * Template Name: fiat-template2
 *
 * This is the template that displays full width page without sidebar
 *
 * @package dazzling
 */

get_header(); ?>
	
<?php while ( have_posts() ) : the_post();
$featureimg= wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
$custom=get_post_custom($post->ID);
// print_r($custom);
$page_title = $post->post_name;
?>

<div class="navfull-width">

<nav class="navbar stickyjeep" id="stickynav" ><!-- data-spy="affix" data-offset-top="110" -->
<a  class="stickylogo"><img class="img-responsive" src="<?php the_field('brand_image');?>" alt=""><?php the_field('brand_text');?></a>    
  <ul class="nav navbar-nav">
    <li><a class="active" href="#Overviewsec">Overview</a></li>
    <li><a href="#capabilitysec" id="capability">Capability</a></li>

  </ul>
<a class="book" href="<?php echo esc_url( home_url( '/' ) ); ?>book-a-test-drive">Book a test drive</a>
</nav>

<!--   Home Banner-->
<div id="Overviewsec">
<section  class="innerbanner" style="background:url('<?php echo $featureimg ?>') no-repeat scroll center center /cover	;"> 
	<div class="container">
    	<div class="row"> 
        	<div class="col-sm-12 col-sm-12 innerbannertext">
        		<div class="bannertext jeep">
        			<?php the_content(); ?>		            
               	</div>
        		
        	</div>

        </div>
    </div>
</section>

<?php 
if( have_rows('variant_row') ): ?>
<section class="variant">
  <div class="container">
    <div class="col-centered table-center pad-50">
       <?php
          while ( have_rows('variant_row') ) : the_row(); ?>    
                <div class="col-md-4 col-sm-4 fiat-cars">
                    <img src="<?php the_sub_field('image');?>">
                    <?php the_sub_field('car_name');?>
                    <hr class="grey">
                    <?php the_sub_field('car-range');?>
                    
                </div>  
      <?php endwhile; ?>
    </div>  
  </div>  
</section>
<?php endif; ?>

<section class="color-variant">
	<div class="container">
		<div class="col-md-7">
      <div class="row">     
			   <img id="myImage"  class="img-responsive" src="<?php echo wp_get_attachment_url( $custom['color_row_0_full_image'][0] );?>" alt="">
		  </div>   
    </div>
		<div class="col-md-5">
            <h3 class="color-title"><?php the_field('color_title');?></h3>
            <span class="color-content"><?php the_field('color_content');?></span>
            <h3 class="color-subtitle">Colour Options</h3>
            <ul class="color-list">
            <?php
              if( have_rows('color_row') ):
              while ( have_rows('color_row') ) : the_row(); ?>    
                <li>
                    <button id="color-button" onclick="document.getElementById('myImage').src='<?php the_sub_field('full_image');?>';document.getElementById('color-name').innerHTML = '<?php the_sub_field('color_name');?>'"><img src="<?php the_sub_field('dot_image');?>"></button>
                </li>
            <?php endwhile; endif; ?>   
            </ul>
            <span id="color-name"><?php echo $custom['color_row_0_color_name'][0] ?></span>
		</div>
	</div>	
</section>

<section class="interior-banner" style="background:url('<?php the_field('interioir_image');?>') no-repeat scroll center top / cover" ;>
    <div class="patter-container"><span class="pattern-text"><?php the_field('interior_text');?></span></div>
</section>

<section class="interior-row">
    <div class="col-md-10 col-centered">
    <?php
      if( have_rows('interior_row') ):
      while ( have_rows('interior_row') ) : the_row(); ?>        
        <div class="int-row">   
            <div class="col-md-6 interiorimage">
                <img class="wow slideInUp" src="<?php the_sub_field('image');?>">
            </div>
            <div class="col-md-6 interiorcontent">
               <?php the_sub_field('content');?>
            </div>
        </div>    
     <?php endwhile; endif; ?>  
    </div> 
    <?php
      if( have_rows('fullwidth') ):
      while ( have_rows('fullwidth') ) : the_row(); ?>         
    <div class="col-centered bgheight" style="background:url('<?php the_sub_field('image');?>') no-repeat scroll center bottom /cover ;">
       <div class="int-row">   
            <div class="col-md-6 interiorimage">
                <!-- <img class="wow slideInUp" src="<?php the_sub_field('image');?>"> -->
            </div>
            <div class="col-md-6 interiorcontent">
               <?php the_sub_field('content');?>
            </div>
        </div>    
    </div>  
    <?php endwhile; endif; ?> 
</section>

</div>

<div id="capabilitysec" >

<section class="interior-banner" style="background:url('<?php the_field('capability_image');?>') no-repeat scroll center top / cover" ;>
    <div class="patter-container"><span class="pattern-text"><?php the_field('capability_text');?></span></div>
</section>

<section class="exterior-row">
    <div class="col-md-10 col-centered">
    <?php
      if( have_rows('capability_row') ):
      while ( have_rows('capability_row') ) : the_row(); ?>        
        <div class="int-row">   
            <div class="col-md-6 interiorimage">
                <img class="wow slideInUp" src="<?php the_sub_field('image');?>">
            </div>
            <div class="col-md-6 interiorcontent">
               <?php the_sub_field('content');?>
            </div>
        </div>    
     <?php endwhile; endif; ?>  
    </div>     
</section>

</div>







</div><!-- navfullwisdth -->





<script>
    new WOW().init();

    jQuery(".tyre-list li  button").on("click", function() {
    jQuery(".tyre-list li button").removeClass("active");
    jQuery(this).addClass("active");
  });


jQuery('#stickynav').affix({
    offset: {
        top: jQuery('#stickynav').offset().top
    }
});


jQuery(document).ready(function () {
    jQuery(document).on("scroll", onScroll);
    
    //smoothscroll
    jQuery('.stickyjeep .nav li a[href^="#"]').on('click', function (e) {
        e.preventDefault();
        jQuery(document).off("scroll");
        
        jQuery('.stickyjeep .nav li a').each(function () {
            jQuery(this).removeClass('active');
        })
        jQuery(this).addClass('active');
      
        var target = this.hash,
            menu = target;
        $target = jQuery(target);
        jQuery('html, body').stop().animate({
            'scrollTop': $target.offset().top}, 500, 'swing', function () {
            window.location.hash = target;
            jQuery(document).on("scroll", onScroll);
        });
    });
});


function onScroll(event){
    var scrollPos = jQuery(document).scrollTop();
   jQuery('#stickynav ul li a').each(function () {
        var currLink = jQuery(this);
        var refElement = jQuery(currLink.attr("href"));
        if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            jQuery('#stickynav ul li a').removeClass("active");
            currLink.addClass("active");
        }
        else{
            currLink.removeClass("active");
        }
    });
}
</script>
<?php endwhile; // end of the loop. ?>	
<?php get_footer(); ?>
 