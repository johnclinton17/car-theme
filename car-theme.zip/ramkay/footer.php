<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package dazzling
 */
?>
                </div><!-- close .row -->
            </div><!-- close .container -->
        </div><!-- close .site-content -->

	<div id="footer-area">
		<div class="container footer-top">
			<div class="col-md-6 pad0"><?php dynamic_sidebar( 'Footer Widget 1' ); ?></div>
			<div class="col-md-6 pad0"><?php dynamic_sidebar( 'Footer Widget 2' ); ?></div>
			<div class="col-md-6 pad0"><?php dynamic_sidebar( 'Footer Widget 3' ); ?></div>
			<div class="col-md-6 pad0"><?php dynamic_sidebar( 'Footer Widget 4' ); ?></div>
		</div>

		<footer class="footer-bottom">
			<div class="site-info container">
				<span class="copyright">&copy; 2017 Ramkay FCA. All rights reserve</span>
				 <?php wp_nav_menu( array(
		                'theme_location'    => 'footer-links',
		                'depth'             => 3,
		                'container'         => '',
		                'container_class'   => '',
		        		'container_id'      => 'navbar-footer',
		                'menu_class'        => 'nav footer-nav',
		                'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
		                'walker'            => new wp_bootstrap_navwalker())
			            );
			        ?>
		
			</div><!-- .site-info -->
			<div class="scroll-to-top"><!-- <i class="fa fa-angle-up"></i> --><span class="wheel"></span><span class="scrolltext">Steer to top</span></div><!-- .scroll-to-top -->
		</footer><!-- #colophon -->
	</div>
</div><!-- #page -->

<?php wp_footer(); ?>

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1989000547984052'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=1989000547984052&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-42630612-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-42630612-1');
</script> -->


<script src="https://cdn.jsdelivr.net/ga-lite/latest/ga-lite.min.js" async></script>
<script>
var galite = galite || {};
galite.UA = 'UA-112386071-1'; // Insert your tracking code here
</script>
</body>
</html>