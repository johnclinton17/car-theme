jQuery(document).ready(function() {
  var flag = false;
  jQuery("#quote-carousel").on('slide.bs.carousel', function(data) {
    if (!flag) {
		
		if(data.direction == 'left') {

      var arr = jQuery('ol.carousel-indicators > li');
      jQuery(jQuery('ol.carousel-indicators')).append(jQuery('ol.carousel-indicators > li')[0]);
      jQuery('.carousel-inner').append(jQuery('.carousel-inner > .item')[0]);
		}
		else {
			var arr = jQuery('ol.carousel-indicators > li');
			jQuery(jQuery('ol.carousel-indicators')).prepend(arr[arr.length - 1]);
			arr = jQuery('.carousel-inner > .item');
			jQuery('.carousel-inner').prepend(arr[arr.length - 1]);
		}
    } else {
      flag = false;
    }
  });

  jQuery('#quote-carousel').carousel(2);

  jQuery(document).on('dblclick', '.item-btn', function() {
	   jQuery('.item-btn').trigger('click')
	  return false;
	  
  });
  //jQuery('.item-btn').click(function(obj) {
  jQuery(document).on('click', '.item-btn', function(obj) {
	   //jQuery('#quote-carousel').carousel(arr.index(obj.currentTarget););
	 
    // flag = true;
    // var arr = jQuery('.item-btn');
    // var index = arr.index(obj.currentTarget);
    // var len = arr.length;
    // var mid = Math.floor(len / 2);
   
    // if (index < mid) {
      // for (i = 0; i < (mid - index); i++) {
        // jQuery(jQuery('ol.carousel-indicators')).prepend(jQuery('.item-btn')[len - 1]);
        // jQuery('.carousel-inner').prepend(jQuery('.item')[len - 1]);
      // }
    // } else if (index > mid) {
      // for (i = 0; i < (index - mid); i++) {
        // jQuery(jQuery('ol.carousel-indicators')).append(jQuery('.item-btn')[0]);
        // jQuery('.carousel-inner').append(jQuery('.item')[0]);
      // }
    // }
	
  });

  jQuery(".left").click(function() {
	 jQuery('#quote-carousel').carousel('prev'); 
    jQuery(window).scrollTop(jQuery('.testimonials').offset().top);
  });
  jQuery(".right").click(function() {
								 
	  jQuery('#quote-carousel').carousel('next');
   
  });
});