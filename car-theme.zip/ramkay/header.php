<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package dazzling
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/inc/css/animate.css">


<body <?php body_class(); ?>>
<div id="page" class="hfeed site">

	<nav class="navbar navbar-default" role="navigation">
		<div class="container">
			<div class="navbar-header">
			  

				<div id="logo">

					<?php echo is_home() ?  '<h1 class="site-title">' : '<span class="site-title">'; ?>

						<?php if( get_header_image() != '' ) : ?>

							<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php header_image(); ?>" width="168" height="89" alt="<?php bloginfo( 'name' ); ?>"/></a>


					<?php endif; // header image was removed ?>

						<?php if( !get_header_image() ) : ?>

							<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>

						<?php endif; // header image was removed (again) ?>

					<?php echo is_home() ?  '</h1>' : '</span>'; ?><!-- end of .site-name -->
<div class="other_logos"><img src="<?php echo get_template_directory_uri();?>/inc/images/jeeptop.png" width="81" height="31" alt=""/> <img src="<?php echo get_template_directory_uri();?>/inc/images/fiattop.png" width="59" height="51" alt=""/> <img src="<?php echo get_template_directory_uri();?>/inc/images/abarthtop.png" width="47" height="52" alt=""/></div>
				</div><!-- end of #logo -->

				<?php if( !get_header_image() ) : ?>

					<?php $description = get_bloginfo( 'description', 'display' );
					if ( $description || is_customize_preview() ) : ?>
						<p class="site-description"><?php echo $description; /* WPCS: xss ok. */ ?></p>
					<?php
					endif; ?>

				<?php endif; ?>
						
			</div>
   <div class="header-right">
  <div class="submenu"><ul><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>book-a-test-drive" class="book_test">Book a test drive</a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>get-a-quote" class="get_quote"> Get a quick quote</a></li><li><a href="<?php echo esc_url( home_url( '/' ) ); ?>service/" class="service"> Service request</a></li><li><span class="icon-phone"> CALL:   994-01-77-000</span></li></ul></div>
				<?php dazzling_header_menu(); ?>
				<!-- <button id="nav-icon2" type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar">
			    	<span></span>
				  <span></span>
				  <span></span>
				  <span></span>
				  <span></span>
				  <span></span>
			  </button> -->
		</div></div>
	</nav><!-- .site-navigation -->
	<script type="text/javascript">
		jQuery(document).ready(function(){
	jQuery('#nav-icon2').click(function(){
		jQuery(this).toggleClass('open');
	});
});

	</script>
        <!--<div class="top-section">
		<?php dazzling_featured_slider(); ?>
		<?php dazzling_call_for_action(); ?>
        </div>-->
        <div id="" class="site-content">

            <div class="main-content-area">
